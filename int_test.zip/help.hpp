#ifndef MP_INT_HELP_HPP
#define MP_INT_HELP_HPP

#include <bits/stdc++.h>

double f(double x){
//    return cos(x*x*x)+3*x*x-sin(41*x)+75;
//    return x*x/(sqrt(x*x+1));
    return x*x;
}
#endif
